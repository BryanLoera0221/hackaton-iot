import type { Config } from "tailwindcss";

export default {
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        canvas: "#F5F8FA",
        ink: "#14213D",
        panel: "#FFFFFF",
        line: "#D8DEE2",
        muted: "#5B6B79",
        calm: "#2C6E7F",
        "calm-soft": "#E4EEF0",
        pending: "#B8791A",
        "pending-soft": "#FBEFDC",
        alert: "#C81E3A",
        "alert-soft": "#FBE4E8",
      },
      fontFamily: {
        sans: [
          "IBM Plex Sans",
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
        ],
      },
      keyframes: {
        pulse_border: {
          "0%, 100%": { borderColor: "#C81E3A" },
          "50%": { borderColor: "#F0879A" },
        },
      },
      animation: {
        "pulse-border": "pulse_border 1.4s ease-in-out infinite",
      },
    },
  },
  plugins: [],
} satisfies Config;
