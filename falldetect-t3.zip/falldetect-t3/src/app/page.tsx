"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "~/trpc/react";

type AlertRow = {
  id: string;
  patientName: string;
  roomLabel: string | null;
  createdAt: string;
  acknowledged: boolean;
};

// Beep corto con Web Audio — nada de archivos .mp3 que empacar para la demo.
function playAlertTone() {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "square";
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.35);
    osc.onended = () => ctx.close();
  } catch {
    // Autoplay bloqueado hasta la primera interacción del usuario: no rompas
    // el flujo por esto, la alerta visual sigue funcionando.
  }
}

function timeAgo(iso: string) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (seconds < 60) return `hace ${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `hace ${minutes} min`;
  const hours = Math.floor(minutes / 60);
  return `hace ${hours} h`;
}

export default function DashboardPage() {
  const alertsQuery = api.alerts.list.useQuery();
  const patientsQuery = api.patients.list.useQuery();
  const acknowledgeMutation = api.alerts.acknowledge.useMutation({
    onSuccess: () => alertsQuery.refetch(),
  });

  const [liveAlerts, setLiveAlerts] = useState<AlertRow[]>([]);
  const hasLoadedHistory = useRef(false);

  // Cuando llega el historial inicial de tRPC, lo volcamos al estado local
  // una sola vez; de ahí en adelante el SSE + las mutaciones lo mantienen al día.
  useEffect(() => {
    if (alertsQuery.data && !hasLoadedHistory.current) {
      hasLoadedHistory.current = true;
      setLiveAlerts(
        alertsQuery.data.map((a) => ({
          id: a.id,
          patientName: a.patient.name,
          roomLabel: a.patient.room?.label ?? null,
          createdAt: a.createdAt.toString(),
          acknowledged: a.acknowledged,
        })),
      );
    }
  }, [alertsQuery.data]);

  useEffect(() => {
    const source = new EventSource("/api/alerts/stream");

    source.addEventListener("fall-alert", (event) => {
      const payload = JSON.parse((event as MessageEvent).data) as {
        id: string;
        patientName: string;
        roomLabel: string | null;
        createdAt: string;
      };
      setLiveAlerts((prev) => [
        { ...payload, acknowledged: false },
        ...prev.filter((a) => a.id !== payload.id),
      ]);
      playAlertTone();
    });

    return () => source.close();
  }, []);

  const acknowledge = useCallback(
    (id: string) => {
      setLiveAlerts((prev) =>
        prev.map((a) => (a.id === id ? { ...a, acknowledged: true } : a)),
      );
      acknowledgeMutation.mutate({ id });
    },
    [acknowledgeMutation],
  );

  const active = liveAlerts.filter((a) => !a.acknowledged);
  const history = liveAlerts.filter((a) => a.acknowledged);

  return (
    <main className="min-h-screen">
      <header className="border-b border-line bg-panel px-6 py-4">
        <h1 className="text-lg font-semibold tracking-tight">FallGuard</h1>
        <p className="text-sm text-muted">Panel de enfermería · detección de caídas en vivo</p>
      </header>

      {/* Banda de alertas activas — lo primero que se ve, se mantiene mientras */}
      {/* haya algo sin atender. */}
      <div className="space-y-2 p-6 pb-0">
        {active.length === 0 ? (
          <div className="rounded-md border border-line bg-panel px-4 py-3 text-sm text-muted">
            Sin caídas activas. Todo tranquilo.
          </div>
        ) : (
          active.map((a) => (
            <div
              key={a.id}
              className="flex items-center justify-between rounded-md border-2 border-alert bg-alert-soft px-4 py-3 animate-pulse-border"
            >
              <div>
                <p className="font-semibold text-alert">
                  Caída detectada — {a.patientName}
                  {a.roomLabel ? ` · Habitación ${a.roomLabel}` : ""}
                </p>
                <p className="text-sm text-muted">{timeAgo(a.createdAt)}</p>
              </div>
              <button
                onClick={() => acknowledge(a.id)}
                className="rounded-md bg-alert px-4 py-2 text-sm font-medium text-white hover:opacity-90"
              >
                Atender
              </button>
            </div>
          ))
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 p-6 md:grid-cols-2">
        <section className="rounded-md border border-line bg-panel">
          <div className="border-b border-line px-4 py-3">
            <h2 className="font-medium">Pacientes monitoreados</h2>
          </div>
          <ul className="divide-y divide-line">
            {patientsQuery.data?.length ? (
              patientsQuery.data.map((p) => (
                <li key={p.id} className="flex items-center justify-between px-4 py-3 text-sm">
                  <span>{p.name}</span>
                  <span className="text-muted">{p.room?.label ?? "sin asignar"}</span>
                </li>
              ))
            ) : (
              <li className="px-4 py-3 text-sm text-muted">
                No hay pacientes cargados — agrégalos en Prisma Studio (`npx prisma studio`).
              </li>
            )}
          </ul>
        </section>

        <section className="rounded-md border border-line bg-panel">
          <div className="border-b border-line px-4 py-3">
            <h2 className="font-medium">Historial de alertas atendidas</h2>
          </div>
          <ul className="divide-y divide-line">
            {history.length ? (
              history.map((a) => (
                <li key={a.id} className="flex items-center justify-between px-4 py-3 text-sm">
                  <span>
                    {a.patientName}
                    {a.roomLabel ? ` · ${a.roomLabel}` : ""}
                  </span>
                  <span className="text-muted">{timeAgo(a.createdAt)}</span>
                </li>
              ))
            ) : (
              <li className="px-4 py-3 text-sm text-muted">Aún no se ha atendido ninguna alerta.</li>
            )}
          </ul>
        </section>
      </div>
    </main>
  );
}
